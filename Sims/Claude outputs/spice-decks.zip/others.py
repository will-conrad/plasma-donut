import subprocess, numpy as np, json, os
def ng(name, net):
    open(f'{name}.cir','w').write(net)
    out=subprocess.run(['ngspice','-b',f'{name}.cir'],capture_output=True,text=True,timeout=600).stdout
    return out
def meas(out):
    r={}
    for l in out.splitlines():
        if '=' in l and not l.strip().startswith(('*','Note','Warning')):
            p=l.split('=')
            try: r[p[0].strip()]=float(p[1].split()[0])
            except: pass
    return r
R={}
# 1) coil tap front end: AC response (source 50 ohm)
ng('fe_ac',"""* coil tap front end AC
V1 s 0 dc 0 ac 1
Rs s a 50
C30 a n 1n
R18 vcc n 10k
R19 n 0 10k
Ci n 0 5p
VCC vcc 0 3.3
.ac dec 50 100 1e9
.control
run
wrdata fe_ac.dat vdb(n)
meas ac g1356 find vdb(n) at=13.56e6
meas ac f3db when vdb(n)=-3 cross=1
.endc
.end""")
R['fe']=meas(open('fe_ac.cir') and ng('fe_ac',open('fe_ac.cir').read()))
# 3) thermistor channel: DC vs temperature + ADC sample kickback transient
T=np.arange(-20,151,1.0); B=3435; R25=10e3
Rn=R25*np.exp(B*(1/(T+273.15)-1/298.15)); v=3.3*Rn/(10e3+Rn); code=np.floor(4096*Rn/(10e3+Rn))
dT_per_lsb=np.abs(np.gradient(T,4096*Rn/(10e3+Rn)))
np.savetxt('therm.dat',np.c_[T,Rn,v,code,dT_per_lsb])
# kickback: MCP3208 Csample 20pF via 1k switch, sampling at 10 kHz per channel, thermistor at 85C
Rn85=R25*np.exp(B*(1/(358.15)-1/298.15))
out=ng('therm_tr',f"""* thermistor channel with ADC sampling
VREF vr 0 3.3
R4 vr n 10k
RNTC n 0 {Rn85:.1f}
C18 n 0 100n
S1 n cs ctl 0 SMP
.model SMP sw vt=0.5 vh=0.1 ron=1k roff=1e12
Cs cs 0 20p
Rleak cs 0 1e9
* sample cap discharged between samples (worst case): reset switch
S2 cs 0 rst 0 SMP
Vctl ctl 0 pulse(0 1 0 10n 10n 1.5u 100u)
Vrst rst 0 pulse(0 1 50u 10n 10n 1u 100u)
.tran 20n 5m 0 20n
.control
set ngbehavior=ltpsa
run
wrdata therm_tr.dat v(n)
meas tran vfinal find v(n) at=4.9m
meas tran vmin min v(n) from=4.5m to=5m
meas tran vmax max v(n) from=4.5m to=5m
meas tran t90 when v(n)={0.9*3.3*Rn85/(10e3+Rn85)} cross=1
.endc
.end""")
R['therm_tr']=meas(out); R['therm_tr']['videal']=3.3*Rn85/(10e3+Rn85)
# 4) VDD divider: DC sweep 0-40 V with Pico pin clamp diode to 3.3 V
out=ng('vdd',"""* VDD divider
VDD vd 0 0
R23 vd n 82k
R8 n 0 10k
C22 n 0 100n
D1 n vc DCL
VC vc 0 3.3
.model DCL d is=1e-14 n=1
.dc VDD 0 40 0.1
.control
run
wrdata vdd_dc.dat v(n) -i(VC)
meas dc v24 find v(n) at=24
meas dc vclampstart when v(n)=3.5 cross=1
meas dc iclamp40 find i(VC) at=40
.endc
.end""")
R['vdd']=meas(out)
out=ng('vdd_step',"""* VDD divider step 0->24 V
VDD vd 0 pwl(0 0 10u 24)
R23 vd n 82k
R8 n 0 10k
C22 n 0 100n
.tran 1u 6m
.control
run
wrdata vdd_step.dat v(n)
meas tran t99 when v(n)=2.583 cross=1
.endc
.end""")
R['vdd_step']=meas(out)
# 5) frequency input: 13.56 MHz and 847.5 kHz square through 330R into ~10 pF (pin + trace)
for tag,f in (('f13',13.56e6),('f847',13.56e6/16)):
    per=1/f
    out=ng(f'freq_{tag}',f"""* freq input {tag}
V1 s 0 pulse(0 3.3 0 2n 2n {per/2-2e-9} {per})
Rs s a 50
R14 a pin 330
Cp pin 0 10p
.tran 0.1n {20*per}
.control
run
wrdata freq_{tag}.dat v(pin)
meas tran tr trig v(pin) val=0.33 rise=5 targ v(pin) val=2.97 rise=5
meas tran vmax max v(pin) from={10*per} to={20*per}
meas tran vmin min v(pin) from={10*per} to={20*per}
.endc
.end""")
    R[tag]=meas(out)
# 5b) 5 V overdrive into GPIO clamp through 330R
out=ng('freq_od',"""* 5V overdrive
V1 s 0 5
R14 s pin 330
D1 pin vc DCL
VC vc 0 3.3
.model DCL d is=1e-14 n=1
.op
.control
run
print -i(VC) v(pin)
.endc
.end""")
R['od_raw']=[l for l in out.splitlines() if '=' in l][-2:]
# 6) backlight: VSYS sweep 4.4-5.2 V
out=ng('bl',"""* backlight
VS v5 0 5
R1 v5 a 24
D1 a k LED
.model LED d is=2e-22 n=2.0 rs=1.5
Q1 k g 0 0 NM
.model NM nmos level=1 vto=1.0 kp=20 
VG g 0 3.3
.dc VS 4.4 5.2 0.01
.control
run
wrdata bl.dat -i(VS) v(a,k)
meas dc i50 find i(VS) at=5.0
meas dc i47 find i(VS) at=4.7
meas dc vf50 find v(a,k) at=5.0
.endc
.end""")
R['bl']=meas(out)
json.dump(R,open('others.json','w'),indent=1)
print(json.dumps(R,indent=1))
