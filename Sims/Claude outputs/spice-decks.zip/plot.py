import json, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
B,O,A,Y='#2a78d6','#eb6834','#1baf7a','#eda100'; T1,T2,G='#0b0b0b','#52514e','#e4e3df'
plt.rcParams.update({'font.size':10,'axes.edgecolor':T2,'axes.labelcolor':T2,'xtick.color':T2,'ytick.color':T2,
  'axes.grid':True,'grid.color':G,'grid.linewidth':0.8,'axes.spines.top':False,'axes.spines.right':False,'lines.linewidth':2,
  'axes.titlesize':11,'axes.titleweight':'bold','axes.titlecolor':T1,'figure.facecolor':'#fcfcfb','axes.facecolor':'#fcfcfb','legend.frameon':False})
r={}
for l in open('phase.log'):
    k,rest=l.split(' ',1); r[k]=eval(rest)
fig,ax=plt.subplots(2,3,figsize=(15,8.6))
# 1 phase transfer
ph=np.arange(0,181,15)
a=ax[0,0]; a.plot(ph,ph,color=T2,lw=1,ls='--',label='Ideal')
a.plot(ph,[r[f'lin_{p}']['vavg']/3.3*180 for p in ph],'o-',color=O,ms=5,label='Current bias (10k/10k = 1.65 V)')
b7={0:0,90:90.1,150:150.0,165:165.0,175:175.0,180:179.9}
a.plot(list(b7),list(b7.values()),'s-',color=B,ms=5,label='Proposed bias (10k/7.15k = 1.38 V)')
a.set(title='1  Phase detector: reading vs true phase',xlabel='True phase A–B (°)',ylabel='Reported phase (°)',xlim=(0,180),ylim=(0,185))
a.annotate('saturates\n≈147°',(152,147),(150,110),color=T1,arrowprops=dict(arrowstyle='->',color=T2))
a.legend(loc='upper left',fontsize=9)
# 2 amplitude mismatch
amps=[0.4,0.5,0.7,1.0,1.5,2.0,3.0]
a=ax[0,1]
a.axhline(0,color=T2,lw=1)
e1=[r[f'mm_{x}']['vavg']/3.3*180-90 for x in amps]; e2=[r[f'mmfix_{x}']['vavg']/3.3*180-90 for x in amps]
a.plot(amps,e1,'o-',color=O,ms=5,label='Current bias'); a.plot(amps,e2,'s-',color=B,ms=5,label='Proposed bias')
a.set(title='2  Error from unequal coil amplitudes',xlabel='Coil B amplitude (V pk), coil A fixed at 1 V pk',ylabel='Phase error at 90° (°)')
a.annotate('current bias: coil B\nnever toggles → stuck',(0.46,-16.6),(1.35,-22),color=T1,arrowprops=dict(arrowstyle='->',color=T2),fontsize=9)
a.legend(loc='lower right',fontsize=9)
# 3 phase filter settling
d=np.loadtxt('step.dat'); a=ax[0,2]
a.plot(d[:,0]*1e3,d[:,1],color=B)
a.axhline(1.65,color=T2,lw=1,ls='--'); a.axvline(17.1,color=O,lw=1.5)
a.text(17.4,0.6,'within 1 LSB\n@ 17 ms',color=T1,fontsize=9)
a.text(2.4,0.95,'τ ≈ 2.1 ms',color=T1,fontsize=9)
a.set(title='3  Phase filter settling (step to 90°)',xlabel='Time (ms)',ylabel='ADC CH6 voltage (V)',xlim=(0,20))
# 4 thermistor
t=np.loadtxt('therm.dat'); a=ax[1,0]
a.plot(t[:,0],t[:,3],color=B,label='ADC code')
a.set(title='4  Thermistor channel (NTC 10k, B=3435)',xlabel='Temperature (°C)',ylabel='MCP3208 code (0–4095)')
a2=a.twinx(); a2.plot(t[:,0],t[:,4],color=O,label='°C per LSB'); a2.set_ylabel('Resolution (°C per LSB)',color=T2); a2.spines['top'].set_visible(False); a2.grid(False); a2.tick_params(colors=T2)
a.legend(loc='upper center',fontsize=9); a2.legend(loc='center right',fontsize=9)
# 5 VDD divider
v=np.loadtxt('vdd_dc.dat'); a=ax[1,1]
a.plot(v[:,0],v[:,1],color=B,label='GP26/27 pin voltage')
a.axhline(3.3,color=O,lw=1.5,ls='--',label='ADC full scale 3.3 V')
a.axvline(24,color=T2,lw=1,ls=':'); a.text(24.4,0.4,'24 V → 2.61 V',color=T1,fontsize=9)
a.text(31,2.3,'reads up to\n≈30.4 V',color=T1,fontsize=9)
a.set(title='5  Oscillator VDD divider (82k / 10k)',xlabel='Oscillator VDD (V)',ylabel='Pico ADC pin (V)',xlim=(0,40)); a.legend(loc='upper left',fontsize=9)
# 6 front end bode
f=np.loadtxt('fe_ac.dat'); a=ax[1,2]
a.semilogx(f[:,0],f[:,1],color=B)
a.axvline(32.4e3,color=T2,lw=1,ls=':'); a.text(38e3,-35,'−3 dB @ 32 kHz',color=T1,fontsize=9)
a.axvline(13.56e6,color=O,lw=1.5); a.text(1.7e6,-45,'13.56 MHz:\n−0.13 dB',color=T1,fontsize=9)
a.set(title='6  Coil-tap input network (1 nF + bias)',xlabel='Frequency (Hz)',ylabel='Gain to Schmitt input (dB)',ylim=(-60,3))
fig.suptitle('Microcontroller board – SPICE test series (ngspice 42)',x=0.01,ha='left',fontsize=14,fontweight='bold',color=T1)
fig.tight_layout(rect=(0,0,1,0.96)); fig.savefig('sim_results.png',dpi=130)
