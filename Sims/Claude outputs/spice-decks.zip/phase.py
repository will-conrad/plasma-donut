import subprocess, os, sys, json, itertools
from concurrent.futures import ThreadPoolExecutor
def deck(ph, ampA=1.0, ampB=1.0, vtp=1.65, vtm=1.10, tdB=0.0, bias_bot=10e3, f=13.56e6, tstop=100e-6):
    vt=(vtp+vtm)/2; vh=(vtp-vtm)/2
    dl = f"TD1 yb 0 ybd 0 Z0=50 TD={tdB}\nRtd ybd 0 50\n" if tdB>0 else "Vz yb ybd 0\n"
    return f"""* phase chain
VCC vcc 0 3.3
VA a 0 sin(0 {ampA} {f} 0 0 0)
VB b 0 sin(0 {ampB} {f} 0 0 {ph})
CA a na 1n
R18 vcc na 10k
R19 na 0 {bias_bot}
CiA na 0 5p
CB b nb 1n
R21 vcc nb 10k
R22 nb 0 {bias_bot}
CiB nb 0 5p
.model SCH sw vt={vt} vh={vh} ron=1 roff=1e9
S1 vcc ya na 0 SCH
RpA ya 0 1k
S2 vcc yb nb 0 SCH
RpB yb 0 1k
{dl}BX x0 0 V=3.3*abs(u(v(ya)-1.65)-u(v(ybd)-1.65))
Ro x0 x 25
R20 x pin 10k
C31 pin 0 100n
R12 pin ph 1k
C26 ph 0 100n
.tran 0.1n {tstop} 0 0.1n
.control
set ngbehavior=ltpsa
run
meas tran vavg avg v(x0) from={tstop-20e-6} to={tstop}
meas tran vpp pp v(ph) from={tstop-10e-6} to={tstop}
meas tran nahi max v(na) from={tstop-1e-6} to={tstop}
meas tran nalo min v(na) from={tstop-1e-6} to={tstop}
.endc
.end
"""
def run(key, **kw):
    fn=f"runs/{key}.cir"; os.makedirs('runs',exist_ok=True); open(fn,'w').write(deck(**kw))
    out=subprocess.run(['ngspice','-b',fn],capture_output=True,text=True,timeout=900).stdout
    r={}
    for line in out.splitlines():
        for k in ('vavg','vpp','t90','nahi','nalo'):
            if line.strip().startswith(k+' ') and '=' in line:
                r[k]=float(line.split('=')[1].split()[0])
    return key,kw,r
jobs=[]
for ph in range(0,181,15):
    jobs.append((f"lin_{ph}",dict(ph=ph)))
    jobs.append((f"linfix_{ph}",dict(ph=ph,bias_bot=6.49e3)))
for amp in (0.4,0.5,0.7,1.0,1.5,2.0,3.0):
    jobs.append((f"mm_{amp}",dict(ph=90,ampA=1.0,ampB=amp)))
    jobs.append((f"mmfix_{amp}",dict(ph=90,ampA=1.0,ampB=amp,bias_bot=6.49e3)))
for td in (0.5e-9,1e-9,2e-9,4.8e-9):
    jobs.append((f"dly_{td}",dict(ph=90,tdB=td,bias_bot=6.49e3)))
for amp in (0.3,0.4,0.5,0.6,0.7,0.8):
    jobs.append((f"min_{amp}",dict(ph=90,ampA=amp,ampB=amp)))
    jobs.append((f"minfix_{amp}",dict(ph=90,ampA=amp,ampB=amp,bias_bot=6.49e3)))
res={}
with ThreadPoolExecutor(2) as ex:
    for key,kw,r in ex.map(lambda j: run(j[0],**j[1]), jobs):
        res[key]={'kw':kw,'r':r}; print(key,r,flush=True)
json.dump(res,open('phase_results.json','w'),indent=1)
